export class Land {

}