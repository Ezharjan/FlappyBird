//导演类控制游戏的整个逻辑
import {DataStore} from "./base/DataStore.js";

export class Director {

    //单例——只允许又一个导演
    static getInstance(){
        if (!Director.instance){
            Director.instance = new Director();
        }
        return Director.instance;
    }

    constructor() {
        //即便多次调用getInstance也只会执行一次。
        //这就是ES6实现单例模式。
        console.log('构造器初始化');

        this.dataStore = DataStore.getInstance();
    }

    run(){
        const backgroundSprite =this.dataStore.get('background');
        backgroundSprite.draw();
    }

}