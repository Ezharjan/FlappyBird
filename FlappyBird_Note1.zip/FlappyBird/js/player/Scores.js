export class Scores {
    
}