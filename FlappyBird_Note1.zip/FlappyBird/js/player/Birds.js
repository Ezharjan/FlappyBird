export class Birds {
    
}